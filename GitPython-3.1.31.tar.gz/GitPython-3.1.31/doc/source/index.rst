.. GitPython documentation master file, created by sphinx-quickstart on Sat Jan 24 11:51:01 2009.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

GitPython Documentation
=======================

.. toctree::
   :maxdepth: 2

   intro
   tutorial
   reference
   roadmap
   changes

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

